﻿Module Module1
    'INFORMATIONS

    'Tranlations:

    'Pendel 3D = Pendulum 3D
    'Einstellungen = settings
    'Start = which is opened upon launching
    'frmPendel = Pendulum 2D
    'Oben, unten, links, rechts = top/up, bottom/down, left, right


    'General task:
    'create pendulum, 2D as well as 3D. 2D unimportant, because finished. However, the amplitude is pulled out of the 2D application
    '3D pendulum is supposed to deliver the following
    '-form of a cuboid, only edges and vertices need to be visible, surfaces not required (can be left blank)
    '-need to be able to adjust size of cuboid and have standard settings via the settings (complete)
    '-coordinate system in which cuboid is moving needs to be visible, middle of cuboid is supposed to be suspended at 0/0/0
    '-buttons Oben, unten, links, rechts are supposed to turn the cuboid/viewing angle by x degrees upon clicking them; reset=reset to original position
    '
    'I think from hereon the pendulum is supposed to swing, should be possible, right?
    '
    'Also required is a graph that shows the amplitude of the pendulum at anytime. It's supposed to be shown next to swinging pendulum, "recording" in real time.




End Module
