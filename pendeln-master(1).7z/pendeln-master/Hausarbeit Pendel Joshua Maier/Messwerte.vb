﻿Public Class Messwerte

End Class