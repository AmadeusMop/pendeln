﻿Public Class frmPendel2D

    'Hier werden die Eigenschaften des Fensters bestimmt
    Private Sub frmPendel2D_Load(sender As Object, e As EventArgs) Handles Me.Load

        DoubleBuffered = True   'Es findet eine doppelte Bufferung statt um ein Flimmern zu reduzieren
        Me.Top = 25             'Position/Abestand des Fensters von oben
        Me.Left = 485           'Position/Abstand des Fensters von links
        Me.Width = 475          'Breite des Fensters
        Me.Height = 375         'Höhe des Fensters
    End Sub


    'Hier wird die Position der Kugel berechnet und das Pendel gezeichnet
    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles Me.Paint


        'Bestimmung von Variablen:
        Dim xAufh, yAufh As Integer                 'Für die x/y-Koordinaten der Aufhängung des Pendels
        Dim x, y As Integer                         'Für die x/y-Koordinaten der Kugel
        Dim faden As New Pen(Color.Black, 2)        'Für die Dicke und die Farbe des Fadens bei der Zeichnung


        'Werte der Aufhängung werden festgelegt
        xAufh = Me.Width / 2    'x-Position der Aufhängung
        yAufh = 50              'y-Position der Aufhängung vom oberen Rand


        'Hier wird die x/y-Koordinate (Position) der pendelnden Kugel berechnet
        x = xAufh + 150 * Math.Sin(frmStart.winkelAuslenk) * frmStart.fadenLaenge
        y = yAufh + 150 * Math.Cos(frmStart.winkelAuslenk) * frmStart.fadenLaenge



        'Hier wird die Funktion der Checkbox zur Fadenlänge bestimmt
        'Wenn die Checkbox aktiviert ist, wird der Faden in der Länge dargestellt, welche in den
        'Einstellungen und Vorgaben festgelegt wurde.
        If chkoriginal.Checked Then
            frmStart.fadenLaenge = frmEinstellVorgab.txtFadenLaenge.Text

            'Wenn sie nicht aktiviert ist, wird die Fadenlänge mit dem Wert 1 dargestellt.
        Else
            frmStart.fadenLaenge = 1
        End If



        ' Zeichnen des Pendels:
        With e.Graphics

            'Glättung (Antialiasing) soll erfolgen:
            .SmoothingMode = Drawing2D.SmoothingMode.HighQuality

            'Zeichnet eine Linie von der Aufhängung zu dem errechneten x/y Punkt
            .DrawLine(faden, xAufh, yAufh, x, y)

            'Füllt das innere einer Ellipse
            'Zeichnet den Punkt der Aufhängung in grün und die Kugel in dunkelgrau
            .FillEllipse(Brushes.Green, x - frmStart.r, y - frmStart.r, frmStart.r * 2, frmStart.r * 2)
            .FillEllipse(Brushes.DarkGray, xAufh - 5, yAufh - 5, 10, 10)
        End With
    End Sub
End Class