﻿Public Class frmStart

    'Eigenschaften des Fenster:
    Private Sub frmStart_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        DoubleBuffered = True   'Es findet eine doppelte Bufferung statt um ein Flimmern zu reduzieren
        Me.Top = 25             'Position/Abestand des Fensters von oben
        Me.Left = 25            'Position/Abstand des Fensters von links
        Me.Width = 435          'Breite des Fensters
        Me.Height = 225         'Höhe des Fensters
    End Sub


    'Hier werden unsere Variablen deklariert. Diese sind alle als public bestimmt, damit man von jedem
    'Fenster/Form darauf zugreifen kann

    Public r As Decimal                     'Für den Radius der Kugel                      
    Public fadenLaenge As Decimal           'Für die Länge des Fadens   
    Public g As Decimal                     'Für den Wert der Gravitation                 

    Public winkelAuslenk As Decimal         'Für den Winkel der Auslenkung                
    Public winkelGeschw As Decimal          'Für den Winkel der Geschwindigkeit        
    Public winkelBeschl As Decimal          'Für den Winkel der Beschleunigung           

    Public n As Decimal                     'Für die jeweilige Position (x-Achse)

    Public phiw(100) As Decimal             'Für 101 Positionen der Auslenkung      
    Public phis(100) As Decimal             'Für 101 Positionen der Geschwindigkeit        
    Public phia(100) As Decimal             'Für 101 Positionen der Beschleunigung

    Public zoom As Integer                  'Zoom-Faktor für die Sinuskurven im Diagramm  
    Public reib As Decimal                  'Für die Reibung                             
 
    Public winkelAuslenkGrad As Decimal     'Für die Umrechnung der Auslenkung              
    Public winkelGeschwSek As Decimal       'Für die Umrechnung der Geschwindigkeit             
    Public winkelBeschlSek As Decimal       'Für die Umrechnung der Beschleunigung             

    Public Zeit As Decimal                  'Für die Ausgabe der Zeit bei den Messwerten     
    Public timercount As Integer = 1        'Für die Berechnung der Zeit                         




    'Der Timer:
    Private Sub Timer1_Tick1(sender As Object, e As EventArgs) Handles Timer1.Tick

        'Hier wird die Beschleunigung, Geschwindigkeit und die Auslenkung berechnet.
        winkelBeschl = -g / fadenLaenge * Math.Sin(winkelAuslenk) - winkelGeschw * 0.1 * reib
        winkelGeschw = winkelGeschw + winkelBeschl * 0.1
        winkelAuslenk = winkelAuslenk + winkelGeschw * 0.1


        'Lopp über die ersten 100 Positionen
        If n < 100 Then                     'Anzahl der gespeicherten Positionen < 100 dann:
            phiw(n) = winkelAuslenk         'Auslenkung wird in das Array an entsprechender Stelle geschrieben
            phis(n) = winkelGeschw          'Geschwindigkeit wird in das Array an entsprechender Stelle geschrieben
            phia(n) = winkelBeschl          'Beschleunigung wird in das Array an entsprechender Stelle geschrieben
            n = n + 1
        Else                                'Anzahl der gespeicherten Position > 100 dann:
            'Loop über die folgenden 100 Positionen
            For i = 0 To 99                 'Gilt für die Positionen 0 bis 99 im Array
                phiw(i) = phiw(i + 1)       'Alle bisherigen Positionen werden um 1 nach hinten verschoben
                phiw(100) = winkelAuslenk   'Letzte Position = neuer Wert der Auslenkung
                phis(i) = phis(i + 1)       'Alle bisherigen Positionen werden um 1 nach hinten verschoben
                phis(100) = winkelGeschw    'Letzte Position = neuer Wert der Geschwindigkeit
                phia(i) = phia(i + 1)       'Alle bisherigen Positionen werden um 1 nach hinten verschoben
                phia(100) = winkelBeschl    'Letzte Position = neuer Wert der Beschleunigung
            Next
        End If



        'Umrechnung und Ausgabe der Messwerte und der Laufzeit:
        winkelAuslenkGrad = winkelAuslenk * (180 / Math.PI)     'Umrechnung von Radiant in Grad         
        winkelGeschwSek = winkelGeschw * (180 / Math.PI)        'Umrechnung von Radiant in Grad             
        winkelBeschlSek = winkelBeschl * (180 / Math.PI)        'Umrechnung von Radiant in Grad             

        frmMesswerte.lblAuslenkungswert1.Text = Format(winkelAuslenkGrad, "0.00" & " ° ")       'Ausgabe in Grad
        frmMesswerte.lblAuslenkungswert2.Text = Format(winkelAuslenk, "0.00" & " rad")          'Ausgabe in Radiant

        frmMesswerte.lblGeschwindigkeitWert1.Text = Format(winkelGeschwSek, "0.00" & " m/s")    'Ausgabe in Grad
        frmMesswerte.lblGeschwindigkeitWert2.Text = Format(winkelGeschw, "0.00" & " rad/s")     'Ausgabe in Radiant

        frmMesswerte.lblBeschleunigungWert1.Text = Format(winkelBeschlSek, "0.00" & " m/s²")    'Ausgabe in Grad
        frmMesswerte.lblBeschleunigungWert2.Text = Format(winkelBeschl, "0.00" & " rad/s²")     'Ausgabe in Radiant


        Zeit = Zeit + timercount / 10                                       'Sekunden werden gezählt
        frmMesswerte.lblZeitanzeige.Text = Format(Zeit, "0.00" & " s")      'Sekunden werden ausgegeben



        Refresh()                       'Refresh
        frmPendel2D.Refresh()           'Refresh der 2D-Form
        frmDiagramm.Refresh()           'Refresh der Diagramm-Form
        frmPendel3D.Refresh()           'Refresh der 3D-Form
    End Sub



    'Start/Stop-Button:
    Private Sub cmdStartStop_Click1(sender As Object, e As EventArgs) Handles cmdStartStop.Click

        frmPendel2D.Show()                      'Das Pendel2D-Fenster wird geöffnet
        If Timer1.Enabled = False Then          'Timer wird aktiviert wenn er vorher nicht lief
            Timer1.Enabled = True
        Else                                    'Sonst
            Timer1.Enabled = False              'wird der Timer deaktiviert
        End If
    End Sub

    'Einstellungen & Vorgaben-Button
    Private Sub cmdEinstellVorgab_Click(sender As Object, e As EventArgs) Handles cmdEinstellVorgab.Click
        If Timer1.Enabled = False Then                          'Wenn der Timer nicht läuft
            frmEinstellVorgab.Show()                            'Einstellungen & Vorgaben öffnen
            For Each ctl In Me.Controls
                If TypeOf ctl Is Button Then
                    DirectCast(ctl, Button).Enabled = False
                End If
            Next
        Else
            Timer1.Enabled = False
        End If
    End Sub


    'Pendel 2D-Button
    Private Sub cmdPendel2D_Click(sender As Object, e As EventArgs) Handles cmdPendel2D.Click
        If frmPendel2D.Visible = True Then          'Anzeige der Pendel2D-Form Ein-/Ausschalten
            frmPendel2D.Hide()
        Else
            frmPendel2D.Show()
        End If
    End Sub


    'Pendel 3D-Button
    Private Sub cmdPendel3D_Click(sender As Object, e As EventArgs) Handles cmdPendel3D.Click
        If frmPendel3D.Visible = True Then          'Anzeige der Pendel3D-Form Ein-/Ausschalten
            frmPendel3D.Hide()
        Else
            frmPendel3D.Show()
        End If
    End Sub

    'Diagramm-Button
    Private Sub cmdDiagramm_Click(sender As Object, e As EventArgs) Handles cmdDiagramm.Click
        If frmDiagramm.Visible = True Then          'Anzeige der Diagramm-Form Ein-/Ausschalten
            frmDiagramm.Hide()
        Else
            zoom = 100
            frmDiagramm.Show()
        End If
    End Sub

    'Messwerte-Button
    Private Sub cmdMesswerte_Click(sender As Object, e As EventArgs) Handles cmdMesswerte.Click
        If frmMesswerte.Visible = True Then         'Anzeige der Messwerte-Form Ein-/Ausschalten
            frmMesswerte.Hide()
        Else
            frmMesswerte.Show()
        End If
    End Sub
End Class
