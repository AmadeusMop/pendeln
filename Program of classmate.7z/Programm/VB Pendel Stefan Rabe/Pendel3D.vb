﻿Public Class frmPendel3D
  
    'Deklaration von Variablen und Array-Indizes:
    Public Breite, Höhe, Tiefe As Integer                   'Breite, Höhe und Tiefe
    Dim xAufh, yAufh As Integer                             'x/y-Position der Aufhängung
    Dim Kante As New Pen(Color.Green, 2)                    'Bestimmung der Farbe und Dicke der Kante
    Dim xNull(11) As Decimal                                'Punkte auf der x-Achse (12 Stk.)
    Dim yNull(11) As Decimal                                'Punkte auf der y-Achse (12 Stk.)
    Dim zNull(11) As Decimal                                'Punkte auf der z-Achse (12 Stk.)
    Dim winkelDrehx, winkelDrehy As Decimal                 'Wert der Drehung durch die Buttons
    Dim xDrehx(11), yDrehx(11), zDrehx(11) As Decimal       'Drehung um die x-Achse
    Dim xDrehy(11), yDrehy(11), zDrehy(11) As Decimal       'Drehung um die y-Achse
    Dim xPendel(11), yPendel(11), zPendel(11) As Decimal    'Drehung um die z-Achse
    Dim xZeichnen(11) As Decimal                            'Punkte inkl. Pendelbewegung
    Dim yZeichnen(11) As Decimal                            'Punkte inkl. Pendelbewegung
    Public winkelPendel As Decimal                          'Gleich der Auslenkung
    Dim koordLinie As New Pen(Color.Red, 3)                 'Linienfarbe und dicke der Koordinaten



    'Hier werden die Eigenschaften des Fensters und der Aufhängung bestimmt
    Private Sub frmPendel3D_Load(sender As Object, e As EventArgs) Handles Me.Load

        DoubleBuffered = True                               'Es findet eine doppelte Bufferung statt um ein Flimmern zu reduzieren
        Me.Top = 275                                        'Position/Abestand des Fensters von oben
        Me.Left = 25                                        'Position/Abstand des Fensters von links
        Me.Width = 400                                      'Breite des Fensters
        Me.Height = 500                                     'Höhe des Fensters

        xAufh = Me.Width / 2                                'x-Position der Aufhängung
        yAufh = 250                                         'y-Position der Aufhängung vom oberen Rand
    End Sub



    Private Sub frmPendel3D_Paint(sender As Object, e As PaintEventArgs) Handles Me.Paint

        winkelPendel = frmStart.winkelAuslenk               'Auslenkung = winkelPendel

        'Jeder Eckpunkt des Quaders wird bestimmt
        For Each i In {0, 3, 4, 7}          '4 Eckpunkte mit den selben Koordinaten auf der x-Achse
            xNull(i) = -Breite / 2
        Next
        For Each i In {1, 2, 5, 6}          '4 Eckpunkte mit den selben Koordinaten auf der x-Achse
            xNull(i) = +Breite / 2
        Next
        For Each i In {4, 5, 6, 7}          '4 Eckpunkte mit den selben Koordinaten auf der y-Achse
            yNull(i) = +Höhe
        Next
        For Each i In {0, 1, 4, 5}          '4 Eckpunkte mit den selben Koordinaten auf der z-Achse         
            zNull(i) = +Tiefe / 2
        Next
        For Each i In {2, 3, 6, 7}          '4 Eckpunkte mit den selben Koordinaten auf der z-Achse
            zNull(i) = -Tiefe / 2
        Next



        'Schleifen für die Achsendrehung

        'Drehen um die x-Achse:
        For i = 0 To 7
            xDrehx(i) = xNull(i)        'x-Achsendrehung in x-Richtung nicht möglich
            yDrehx(i) = yNull(i) * Math.Cos(winkelDrehx) + zNull(i) * Math.Sin(winkelDrehx)     'In y-Richtung
            zDrehx(i) = -yNull(i) * Math.Sin(winkelDrehx) + zNull(i) * Math.Cos(winkelDrehx)    'In z-Richtung
        Next


        'Drehen um die y-Achse
        For i = 0 To 7
            xDrehy(i) = xDrehx(i) * Math.Cos(winkelDrehy) + zDrehx(i) * Math.Sin(winkelDrehy)   'in x-Richtung
            yDrehy(i) = yDrehx(i)       'y-Achsendrehung in y-Richtung nicht möglich
            zDrehy(i) = -xDrehx(i) * Math.Sin(winkelDrehy) + zDrehx(i) * Math.Cos(winkelDrehy)  'in z-Richtung
        Next


       
        'Hier bringen wir das Quader mit Hilfe der Auslenkung ins pendeln
        For i = 0 To 7
            xPendel(i) = xDrehy(i) * Math.Cos(winkelPendel) + yDrehy(i) * Math.Sin(winkelPendel)
            yPendel(i) = -xDrehy(i) * Math.Sin(winkelPendel) + yDrehy(i) * Math.Cos(winkelPendel)
            zPendel(i) = zDrehy(i)
        Next

       
        'Koordinaten der Aufhängung + den Wert des jeweiligen Punktes zur genauen Positionsbestimmung
        For i = 0 To 7
            xZeichnen(i) = xAufh + xPendel(i) 'Zeichnung auf der x-Achse: Aufhängung + xPendelBewegung
            yZeichnen(i) = yAufh + yPendel(i) 'Zeichnung auf der y-Achse: Aufhängung + yPendelBewegung
        Next



        'Hier werden die einzelnen Linien von den jeweiligen Eckpunkten gezeichnet.
        'Zeichnung der Linien von Ecke 0 zu den Ecken 1, 3 und 4
        For Each i In {1, 3, 4}
            e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            e.Graphics.DrawLine(Kante, xZeichnen(0), yZeichnen(0), xZeichnen(i), yZeichnen(i))
        Next

        'Zeichnung der Linien von der Ecke 2 zu den Ecken 3, 1 und 6
        For Each i In {3, 1, 6}
            e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            e.Graphics.DrawLine(Kante, xZeichnen(2), yZeichnen(2), xZeichnen(i), yZeichnen(i))
        Next

        'Zeichnung der Linien von der Ecke 5 zu den Ecken 4, 1 und 6
        For Each i In {4, 1, 6}
            e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            e.Graphics.DrawLine(Kante, xZeichnen(5), yZeichnen(5), xZeichnen(i), yZeichnen(i))
        Next

        'Zeichnung der Linien von der Ecke 7 zu den Ecken 4, 6 und 3
        For Each i In {4, 6, 3}
            e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            e.Graphics.DrawLine(Kante, xZeichnen(7), yZeichnen(7), xZeichnen(i), yZeichnen(i))
        Next


        'Hier werden die schwarzen Eckpunkte mit den Maßen 4x4 gezeichnet
        For i = 0 To 7
            e.Graphics.FillEllipse(Brushes.Black, xZeichnen(i) - 2, yZeichnen(i) - 2, 4, 4)
        Next


        'Hier wird das Koordinatensystem erstellt und gezeichnet
        'Zuerst werden die Endpunkte der Achsen bestimmt:
        If chkKoordSystem.Checked = True Then
            xNull(8) = yNull(8) = 0
            xNull(9) = 50               'x-Position der x-Achse
            yNull(9) = 0                'y-Position der x-Achse
            xNull(10) = 0               'x-Position der y-Achse
            yNull(10) = -50             'y-Position der y-Achse
            xNull(11) = -28             'x-Position der z-Achse
            yNull(11) = 28              'y-Position der z-Achse


            'Addition der Aufhängung und x/y-Positionen des Koordinatensystems
            For i = 8 To 11
                xZeichnen(i) = xAufh + xNull(i)
                yZeichnen(i) = yAufh + yNull(i)
            Next


            'Pfeilspitze, Antialiasing und Zeichnung der Linien
            For i = 9 To 11
                koordLinie.EndCap = Drawing2D.LineCap.ArrowAnchor
                e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality

                '(8) ist die Aufhängung, von dieser werden 3 Linien gezeichnet.
                e.Graphics.DrawLine(koordLinie, xZeichnen(8), yZeichnen(8), xZeichnen(i), yZeichnen(i))
            Next
        End If

    End Sub

    'Button für die Drehung nach oben
    Private Sub cmdOben_Click(sender As Object, e As EventArgs) Handles cmdOben.Click
        winkelDrehx = winkelDrehx + 0.1     'Pro Klick wird der Wert um 0.1 angehoben
    End Sub

    'Button für die Drehung nach rechts
    Private Sub cmdRechts_Click(sender As Object, e As EventArgs) Handles cmdRechts.Click
        winkelDrehy = winkelDrehy + 0.1     'Pro Klick wird der Wert um 0.1 angehoben
    End Sub

    'Button für die Drehung nach unten
    Private Sub cmdUnten_Click(sender As Object, e As EventArgs) Handles cmdUnten.Click
        winkelDrehx = winkelDrehx - 0.1     'Pro Klick wird der Wert um 0.1 angehoben
    End Sub

    'Button für die Drehung nach links
    Private Sub cmdLinks_Click(sender As Object, e As EventArgs) Handles cmdLinks.Click
        winkelDrehy = winkelDrehy - 0.1     'Pro Klick wird der Wert um 0.1 angehoben
    End Sub

    'Button für den Reset
    Private Sub cmdReset_Click(sender As Object, e As EventArgs) Handles cmdReset.Click
        winkelDrehx = 0                 'Wert wird auf 0 gesetzt
        winkelDrehy = 0                 'Wert wird auf 0 gesetzt
    End Sub
End Class