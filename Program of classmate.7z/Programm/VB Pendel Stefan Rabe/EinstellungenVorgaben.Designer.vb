﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEinstellVorgab
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdEinstellSpeich = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtWinkelMax = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblPendel2D = New System.Windows.Forms.Label()
        Me.lblFadenlaengeAnzeige = New System.Windows.Forms.Label()
        Me.lblKugelRadius = New System.Windows.Forms.Label()
        Me.txtFadenLaenge = New System.Windows.Forms.TextBox()
        Me.txtKugelRadius = New System.Windows.Forms.TextBox()
        Me.lblStandortPlanet = New System.Windows.Forms.Label()
        Me.cmbStandortPlanet = New System.Windows.Forms.ComboBox()
        Me.cmbbreite = New System.Windows.Forms.ComboBox()
        Me.cmbHöhe = New System.Windows.Forms.ComboBox()
        Me.cmbTiefe = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.cmbReibung = New System.Windows.Forms.ComboBox()
        Me.lblReibungsfaktor = New System.Windows.Forms.Label()
        Me.lblPhyVorgaben = New System.Windows.Forms.Label()
        Me.lblPendel3dAnzeige = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdEinstellSpeich
        '
        Me.cmdEinstellSpeich.Location = New System.Drawing.Point(61, 345)
        Me.cmdEinstellSpeich.Name = "cmdEinstellSpeich"
        Me.cmdEinstellSpeich.Size = New System.Drawing.Size(185, 29)
        Me.cmdEinstellSpeich.TabIndex = 0
        Me.cmdEinstellSpeich.Text = "Einstellungen/ Vorgaben speichern"
        Me.cmdEinstellSpeich.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(117, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Winkel Auslenkung in °"
        '
        'txtWinkelMax
        '
        Me.txtWinkelMax.Location = New System.Drawing.Point(173, 82)
        Me.txtWinkelMax.Name = "txtWinkelMax"
        Me.txtWinkelMax.Size = New System.Drawing.Size(125, 20)
        Me.txtWinkelMax.TabIndex = 2
        Me.txtWinkelMax.Text = "45"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(49, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(200, 19)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Einstellungen / Vorgaben"
        '
        'lblPendel2D
        '
        Me.lblPendel2D.AutoSize = True
        Me.lblPendel2D.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lblPendel2D.Location = New System.Drawing.Point(14, 183)
        Me.lblPendel2D.Name = "lblPendel2D"
        Me.lblPendel2D.Size = New System.Drawing.Size(80, 16)
        Me.lblPendel2D.TabIndex = 4
        Me.lblPendel2D.Text = "Pendel 2D"
        '
        'lblFadenlaengeAnzeige
        '
        Me.lblFadenlaengeAnzeige.AutoSize = True
        Me.lblFadenlaengeAnzeige.Location = New System.Drawing.Point(33, 212)
        Me.lblFadenlaengeAnzeige.Name = "lblFadenlaengeAnzeige"
        Me.lblFadenlaengeAnzeige.Size = New System.Drawing.Size(85, 13)
        Me.lblFadenlaengeAnzeige.TabIndex = 5
        Me.lblFadenlaengeAnzeige.Text = "Fadenlänge in m"
        '
        'lblKugelRadius
        '
        Me.lblKugelRadius.AutoSize = True
        Me.lblKugelRadius.Location = New System.Drawing.Point(33, 240)
        Me.lblKugelRadius.Name = "lblKugelRadius"
        Me.lblKugelRadius.Size = New System.Drawing.Size(90, 13)
        Me.lblKugelRadius.TabIndex = 6
        Me.lblKugelRadius.Text = "Kugelradius in cm"
        '
        'txtFadenLaenge
        '
        Me.txtFadenLaenge.Location = New System.Drawing.Point(173, 205)
        Me.txtFadenLaenge.Name = "txtFadenLaenge"
        Me.txtFadenLaenge.Size = New System.Drawing.Size(125, 20)
        Me.txtFadenLaenge.TabIndex = 7
        Me.txtFadenLaenge.Text = "1,5"
        '
        'txtKugelRadius
        '
        Me.txtKugelRadius.Location = New System.Drawing.Point(173, 237)
        Me.txtKugelRadius.Name = "txtKugelRadius"
        Me.txtKugelRadius.Size = New System.Drawing.Size(125, 20)
        Me.txtKugelRadius.TabIndex = 8
        Me.txtKugelRadius.Text = "15"
        '
        'lblStandortPlanet
        '
        Me.lblStandortPlanet.AutoSize = True
        Me.lblStandortPlanet.Location = New System.Drawing.Point(33, 138)
        Me.lblStandortPlanet.Name = "lblStandortPlanet"
        Me.lblStandortPlanet.Size = New System.Drawing.Size(80, 13)
        Me.lblStandortPlanet.TabIndex = 9
        Me.lblStandortPlanet.Text = "Standort Planet"
        '
        'cmbStandortPlanet
        '
        Me.cmbStandortPlanet.FormattingEnabled = True
        Me.cmbStandortPlanet.Items.AddRange(New Object() {"Merkur ", "Venus", "Erde", "Mond", "Mars", "Jupier", "Saturn", "Uranus", "Neptun", "Pluto"})
        Me.cmbStandortPlanet.Location = New System.Drawing.Point(173, 135)
        Me.cmbStandortPlanet.Name = "cmbStandortPlanet"
        Me.cmbStandortPlanet.Size = New System.Drawing.Size(125, 21)
        Me.cmbStandortPlanet.TabIndex = 10
        '
        'cmbbreite
        '
        Me.cmbbreite.FormattingEnabled = True
        Me.cmbbreite.Items.AddRange(New Object() {"5", "10", "15", "20", "25", "30", "40", "50", "60", "70", "80", "90", "100"})
        Me.cmbbreite.Location = New System.Drawing.Point(72, 306)
        Me.cmbbreite.Name = "cmbbreite"
        Me.cmbbreite.Size = New System.Drawing.Size(45, 21)
        Me.cmbbreite.TabIndex = 11
        Me.cmbbreite.Text = "60"
        '
        'cmbHöhe
        '
        Me.cmbHöhe.FormattingEnabled = True
        Me.cmbHöhe.Items.AddRange(New Object() {"10", "20", "30", "40", "60", "80", "100", "120", "140", "160", "180", "200"})
        Me.cmbHöhe.Location = New System.Drawing.Point(162, 306)
        Me.cmbHöhe.Name = "cmbHöhe"
        Me.cmbHöhe.Size = New System.Drawing.Size(45, 21)
        Me.cmbHöhe.TabIndex = 12
        Me.cmbHöhe.Text = "100"
        '
        'cmbTiefe
        '
        Me.cmbTiefe.FormattingEnabled = True
        Me.cmbTiefe.Items.AddRange(New Object() {"5", "10", "15", "20", "25", "30", "40", "50", "60", "70", "80", "90", "100"})
        Me.cmbTiefe.Location = New System.Drawing.Point(253, 306)
        Me.cmbTiefe.Name = "cmbTiefe"
        Me.cmbTiefe.Size = New System.Drawing.Size(45, 21)
        Me.cmbTiefe.TabIndex = 13
        Me.cmbTiefe.Text = "50"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 309)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Breite:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(123, 309)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(36, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Höhe:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(213, 309)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 13)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Tiefe:"
        '
        'cmbReibung
        '
        Me.cmbReibung.FormattingEnabled = True
        Me.cmbReibung.Items.AddRange(New Object() {"keine Reibung", "sehr gering", "gering", "mittel", "stark", "sehr stark"})
        Me.cmbReibung.Location = New System.Drawing.Point(173, 108)
        Me.cmbReibung.Name = "cmbReibung"
        Me.cmbReibung.Size = New System.Drawing.Size(125, 21)
        Me.cmbReibung.TabIndex = 17
        '
        'lblReibungsfaktor
        '
        Me.lblReibungsfaktor.AutoSize = True
        Me.lblReibungsfaktor.Location = New System.Drawing.Point(33, 111)
        Me.lblReibungsfaktor.Name = "lblReibungsfaktor"
        Me.lblReibungsfaktor.Size = New System.Drawing.Size(50, 13)
        Me.lblReibungsfaktor.TabIndex = 18
        Me.lblReibungsfaktor.Text = "Reibung:"
        '
        'lblPhyVorgaben
        '
        Me.lblPhyVorgaben.AutoSize = True
        Me.lblPhyVorgaben.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lblPhyVorgaben.Location = New System.Drawing.Point(14, 55)
        Me.lblPhyVorgaben.Name = "lblPhyVorgaben"
        Me.lblPhyVorgaben.Size = New System.Drawing.Size(176, 16)
        Me.lblPhyVorgaben.TabIndex = 19
        Me.lblPhyVorgaben.Text = "Physikalische Vorgaben"
        '
        'lblPendel3dAnzeige
        '
        Me.lblPendel3dAnzeige.AutoSize = True
        Me.lblPendel3dAnzeige.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold)
        Me.lblPendel3dAnzeige.Location = New System.Drawing.Point(14, 277)
        Me.lblPendel3dAnzeige.Name = "lblPendel3dAnzeige"
        Me.lblPendel3dAnzeige.Size = New System.Drawing.Size(80, 16)
        Me.lblPendel3dAnzeige.TabIndex = 20
        Me.lblPendel3dAnzeige.Text = "Pendel 3D"
        '
        'frmEinstellVorgab
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(314, 393)
        Me.Controls.Add(Me.lblPendel3dAnzeige)
        Me.Controls.Add(Me.lblPhyVorgaben)
        Me.Controls.Add(Me.lblReibungsfaktor)
        Me.Controls.Add(Me.cmbReibung)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.cmbTiefe)
        Me.Controls.Add(Me.cmbHöhe)
        Me.Controls.Add(Me.cmbbreite)
        Me.Controls.Add(Me.cmbStandortPlanet)
        Me.Controls.Add(Me.lblStandortPlanet)
        Me.Controls.Add(Me.txtKugelRadius)
        Me.Controls.Add(Me.txtFadenLaenge)
        Me.Controls.Add(Me.lblKugelRadius)
        Me.Controls.Add(Me.lblFadenlaengeAnzeige)
        Me.Controls.Add(Me.lblPendel2D)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtWinkelMax)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmdEinstellSpeich)
        Me.Name = "frmEinstellVorgab"
        Me.Text = "EinstellungenVorgaben"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdEinstellSpeich As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtWinkelMax As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblPendel2D As System.Windows.Forms.Label
    Friend WithEvents lblFadenlaengeAnzeige As System.Windows.Forms.Label
    Friend WithEvents lblKugelRadius As System.Windows.Forms.Label
    Friend WithEvents txtFadenLaenge As System.Windows.Forms.TextBox
    Friend WithEvents txtKugelRadius As System.Windows.Forms.TextBox
    Friend WithEvents lblStandortPlanet As System.Windows.Forms.Label
    Friend WithEvents cmbStandortPlanet As System.Windows.Forms.ComboBox
    Friend WithEvents cmbbreite As System.Windows.Forms.ComboBox
    Friend WithEvents cmbHöhe As System.Windows.Forms.ComboBox
    Friend WithEvents cmbTiefe As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cmbReibung As System.Windows.Forms.ComboBox
    Friend WithEvents lblReibungsfaktor As System.Windows.Forms.Label
    Friend WithEvents lblPhyVorgaben As System.Windows.Forms.Label
    Friend WithEvents lblPendel3dAnzeige As System.Windows.Forms.Label
End Class
