﻿Public Class frmEinstellVorgab

    'Deklarierte Variablen:

    Public n As Integer


    Private Sub cmdEinstellSpeich_Click(sender As Object, e As EventArgs) Handles cmdEinstellSpeich.Click

        'Es wird überprüft ob der eingegebene Wert in die Variable geschrieben werden kann.
        'Wenn dies nicht möglich ist, wird eine Fehlermeldung ausgegeben

        Dim a As Boolean = True                         'Boolsche Variable zur Prüfung der Gültigkeit von Eingaben,Startwert: TRUE
        txtWinkelMax.BackColor = Color.White            'Hintergrundfarbe der textbox = weiß


        'Überprüfung der Möglichkeit der Eingabe für den Winkel der Auslenkung
        Try
            frmStart.winkelAuslenk = txtWinkelMax.Text  'Prüfung gegen Definition der Variable
        Catch ex As Exception                           'wenn nicht gültig
            a = False                                   'dann Boolsche Variable auf FALSE
            txtWinkelMax.BackColor = Color.Red          'und Hintergrundfarbe auf rot
        End Try


        'Überprüfung der Möglichkeit der Eingabe für die Fadenlänge
        Try
            frmStart.fadenLaenge = txtFadenLaenge.Text  'Prüfung gegen Definition der Variable
        Catch ex As Exception                           'wenn nicht gültig
            a = False                                   'dann Boolsche Variable auf FALSE
            txtFadenLaenge.BackColor = Color.Red        'und Hintergrundfarbe auf rot
        End Try


        'Überprüfung der Möglichkeit der Eingabe für den Kugelradius
        Try
            frmStart.r = txtKugelRadius.Text            'Prüfung gegen Definition der Variable
        Catch ex As Exception                           'wenn nicht gültig
            a = False                                   'dann Boolsche Variable auf FALSE
            txtKugelRadius.BackColor = Color.Red        'und Hintergrundfarbe auf rot
        End Try



        'Zuweisung der Werte für die Fallbeschleunigung
        Select Case cmbStandortPlanet.SelectedIndex
            Case 0
                frmStart.g = 3.7            'Merkur
            Case 1
                frmStart.g = 8.87           'Venus
            Case 2
                frmStart.g = 9.81           'Erde
            Case 3
                frmStart.g = 1.6            'Mond
            Case 4
                frmStart.g = 3.71           'Mars
            Case 5
                frmStart.g = 23.12          'Jupiter
            Case 6
                frmStart.g = 8.96           'Saturn
            Case 7
                frmStart.g = 8.69           'Uranus
            Case 8
                frmStart.g = 11             'Neptun
            Case 9
                frmStart.g = 0.72           'Pluto
        End Select

        'Zuweisung der Werte für die Reibung
        Select Case cmbReibung.SelectedIndex
            Case 0
                frmStart.reib = 0           'keine Reibung
            Case 1
                frmStart.reib = 0.5         'sehr gering
            Case 2
                frmStart.reib = 1.5         'gering
            Case 3
                frmStart.reib = 3           'mittel
            Case 4
                frmStart.reib = 5.5         'stark
            Case 5
                frmStart.reib = 6           'sehr stark
        End Select


        'Zuweisung der Maße für das 3D-Pendel:
        frmPendel3D.Breite = cmbbreite.Text
        frmPendel3D.Höhe = cmbHöhe.Text
        frmPendel3D.Tiefe = cmbTiefe.Text



        'Sind die Eingaben alle möglich? Dann:
        If a = True Then
            'Ja, dann Eingabe von Radiant in Grad umwandeln und zuweisen:
            frmStart.winkelAuslenk = frmStart.winkelAuslenk * Math.PI / 180
            Me.Hide()
            For Each ctl In frmStart.Controls                   'Alle Buttons aktivieren
                If TypeOf ctl Is Button Then
                    DirectCast(ctl, Button).Enabled = True
                End If
            Next
            n = 0

            'Wenn nicht alle Eingaben in Ordnung sind:
            'Folgende Fehlermeldung ausgeben:
        Else
            MessageBox.Show("Ungültige Eingabe - ! Verwenden Sie nur Zahlen ! ")
        End If
    End Sub



    Private Sub frmEinstellVorgab_Load(sender As Object, e As EventArgs) Handles Me.Load

        'Eigenschaften des Fensters:
        DoubleBuffered = True   'Es findet eine doppelte Bufferung statt um ein Flimmern zu reduzieren
        Me.Top = 275             'Position/Abestand des Fensters von oben
        Me.Left = 25            'Position/Abstand des Fensters von links
        Me.Width = 330          'Breite des Fensters
        Me.Height = 425         'Höhe des Fensters


        'Standardwerte werden festgelegt:
        cmbStandortPlanet.SelectedIndex = 2         'Default-Wert für den Standort
        cmbReibung.SelectedIndex = 2                'Default-Wert für die Reibung
    End Sub
End Class