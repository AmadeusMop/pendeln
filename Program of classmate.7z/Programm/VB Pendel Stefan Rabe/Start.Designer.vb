﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStart
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblStefanRabe = New System.Windows.Forms.Label()
        Me.cmdStartStop = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.cmdPendel2D = New System.Windows.Forms.Button()
        Me.cmdEinstellVorgab = New System.Windows.Forms.Button()
        Me.cmdPendel3D = New System.Windows.Forms.Button()
        Me.cmdDiagramm = New System.Windows.Forms.Button()
        Me.cmdMesswerte = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblStefanRabe
        '
        Me.lblStefanRabe.AutoSize = True
        Me.lblStefanRabe.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStefanRabe.Location = New System.Drawing.Point(133, 15)
        Me.lblStefanRabe.Name = "lblStefanRabe"
        Me.lblStefanRabe.Size = New System.Drawing.Size(173, 18)
        Me.lblStefanRabe.TabIndex = 0
        Me.lblStefanRabe.Text = "VB Pendel Stefan Rabe"
        '
        'cmdStartStop
        '
        Me.cmdStartStop.Enabled = False
        Me.cmdStartStop.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdStartStop.Location = New System.Drawing.Point(12, 53)
        Me.cmdStartStop.Name = "cmdStartStop"
        Me.cmdStartStop.Size = New System.Drawing.Size(394, 40)
        Me.cmdStartStop.TabIndex = 1
        Me.cmdStartStop.Text = "Start / Stop"
        Me.cmdStartStop.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        '
        'cmdPendel2D
        '
        Me.cmdPendel2D.Enabled = False
        Me.cmdPendel2D.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPendel2D.Location = New System.Drawing.Point(12, 145)
        Me.cmdPendel2D.Name = "cmdPendel2D"
        Me.cmdPendel2D.Size = New System.Drawing.Size(94, 30)
        Me.cmdPendel2D.TabIndex = 2
        Me.cmdPendel2D.Text = "2D Pendel"
        Me.cmdPendel2D.UseVisualStyleBackColor = True
        '
        'cmdEinstellVorgab
        '
        Me.cmdEinstellVorgab.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdEinstellVorgab.Location = New System.Drawing.Point(12, 99)
        Me.cmdEinstellVorgab.Name = "cmdEinstellVorgab"
        Me.cmdEinstellVorgab.Size = New System.Drawing.Size(394, 40)
        Me.cmdEinstellVorgab.TabIndex = 3
        Me.cmdEinstellVorgab.Text = "Einstellungen / Vorgaben"
        Me.cmdEinstellVorgab.UseVisualStyleBackColor = True
        '
        'cmdPendel3D
        '
        Me.cmdPendel3D.Enabled = False
        Me.cmdPendel3D.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPendel3D.Location = New System.Drawing.Point(112, 145)
        Me.cmdPendel3D.Name = "cmdPendel3D"
        Me.cmdPendel3D.Size = New System.Drawing.Size(94, 30)
        Me.cmdPendel3D.TabIndex = 4
        Me.cmdPendel3D.Text = "3D Pendel"
        Me.cmdPendel3D.UseVisualStyleBackColor = True
        '
        'cmdDiagramm
        '
        Me.cmdDiagramm.Enabled = False
        Me.cmdDiagramm.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdDiagramm.Location = New System.Drawing.Point(312, 145)
        Me.cmdDiagramm.Name = "cmdDiagramm"
        Me.cmdDiagramm.Size = New System.Drawing.Size(94, 30)
        Me.cmdDiagramm.TabIndex = 5
        Me.cmdDiagramm.Text = "Diagramm"
        Me.cmdDiagramm.UseVisualStyleBackColor = True
        '
        'cmdMesswerte
        '
        Me.cmdMesswerte.Enabled = False
        Me.cmdMesswerte.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMesswerte.Location = New System.Drawing.Point(212, 145)
        Me.cmdMesswerte.Name = "cmdMesswerte"
        Me.cmdMesswerte.Size = New System.Drawing.Size(94, 30)
        Me.cmdMesswerte.TabIndex = 6
        Me.cmdMesswerte.Text = "Messwerte"
        Me.cmdMesswerte.UseVisualStyleBackColor = True
        '
        'frmStart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(430, 197)
        Me.Controls.Add(Me.cmdMesswerte)
        Me.Controls.Add(Me.cmdDiagramm)
        Me.Controls.Add(Me.cmdPendel3D)
        Me.Controls.Add(Me.cmdEinstellVorgab)
        Me.Controls.Add(Me.cmdPendel2D)
        Me.Controls.Add(Me.cmdStartStop)
        Me.Controls.Add(Me.lblStefanRabe)
        Me.Name = "frmStart"
        Me.Text = "Start"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblStefanRabe As System.Windows.Forms.Label
    Friend WithEvents cmdStartStop As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents cmdPendel2D As System.Windows.Forms.Button
    Friend WithEvents cmdEinstellVorgab As System.Windows.Forms.Button
    Friend WithEvents cmdPendel3D As System.Windows.Forms.Button
    Friend WithEvents cmdDiagramm As System.Windows.Forms.Button
    Friend WithEvents cmdMesswerte As System.Windows.Forms.Button

End Class
