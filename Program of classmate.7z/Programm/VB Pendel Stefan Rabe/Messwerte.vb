﻿Public Class frmMesswerte

    Private Sub frmMesswerte_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Eigenschaften des Fenster:
        DoubleBuffered = True   'Es findet eine doppelte Bufferung statt um ein Flimmern zu reduzieren
        Me.Top = 425             'Position/Abestand des Fensters von oben
        Me.Left = 450            'Position/Abstand des Fensters von links
        Me.Width = 330          'Breite des Fensters
        Me.Height = 180         'Höhe des Fensters

    End Sub
End Class