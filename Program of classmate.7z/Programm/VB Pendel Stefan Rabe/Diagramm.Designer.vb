﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDiagramm
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdAutoscale = New System.Windows.Forms.Button()
        Me.cmdReset = New System.Windows.Forms.Button()
        Me.cmdZoomminus = New System.Windows.Forms.Button()
        Me.cmdZoomplus = New System.Windows.Forms.Button()
        Me.chkGeschw = New System.Windows.Forms.CheckBox()
        Me.chkBeschl = New System.Windows.Forms.CheckBox()
        Me.chkAuslenk = New System.Windows.Forms.CheckBox()
        Me.optLinie = New System.Windows.Forms.RadioButton()
        Me.optPunkt = New System.Windows.Forms.RadioButton()
        Me.lblZoomwert = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdAutoscale
        '
        Me.cmdAutoscale.Location = New System.Drawing.Point(150, 9)
        Me.cmdAutoscale.Name = "cmdAutoscale"
        Me.cmdAutoscale.Size = New System.Drawing.Size(101, 29)
        Me.cmdAutoscale.TabIndex = 0
        Me.cmdAutoscale.Text = "Autoscale"
        Me.cmdAutoscale.UseVisualStyleBackColor = True
        '
        'cmdReset
        '
        Me.cmdReset.Location = New System.Drawing.Point(364, 9)
        Me.cmdReset.Name = "cmdReset"
        Me.cmdReset.Size = New System.Drawing.Size(101, 29)
        Me.cmdReset.TabIndex = 1
        Me.cmdReset.Text = "Reset"
        Me.cmdReset.UseVisualStyleBackColor = True
        '
        'cmdZoomminus
        '
        Me.cmdZoomminus.Location = New System.Drawing.Point(471, 9)
        Me.cmdZoomminus.Name = "cmdZoomminus"
        Me.cmdZoomminus.Size = New System.Drawing.Size(101, 29)
        Me.cmdZoomminus.TabIndex = 2
        Me.cmdZoomminus.Text = "Zoom -"
        Me.cmdZoomminus.UseVisualStyleBackColor = True
        '
        'cmdZoomplus
        '
        Me.cmdZoomplus.Location = New System.Drawing.Point(257, 9)
        Me.cmdZoomplus.Name = "cmdZoomplus"
        Me.cmdZoomplus.Size = New System.Drawing.Size(101, 29)
        Me.cmdZoomplus.TabIndex = 3
        Me.cmdZoomplus.Text = "Zoom +"
        Me.cmdZoomplus.UseVisualStyleBackColor = True
        '
        'chkGeschw
        '
        Me.chkGeschw.AutoSize = True
        Me.chkGeschw.ForeColor = System.Drawing.Color.Blue
        Me.chkGeschw.Location = New System.Drawing.Point(289, 44)
        Me.chkGeschw.Name = "chkGeschw"
        Me.chkGeschw.Size = New System.Drawing.Size(104, 17)
        Me.chkGeschw.TabIndex = 4
        Me.chkGeschw.Text = "Geschwindigkeit"
        Me.chkGeschw.UseVisualStyleBackColor = True
        '
        'chkBeschl
        '
        Me.chkBeschl.AutoSize = True
        Me.chkBeschl.ForeColor = System.Drawing.Color.Green
        Me.chkBeschl.Location = New System.Drawing.Point(399, 44)
        Me.chkBeschl.Name = "chkBeschl"
        Me.chkBeschl.Size = New System.Drawing.Size(102, 17)
        Me.chkBeschl.TabIndex = 5
        Me.chkBeschl.Text = "Beschleunigung"
        Me.chkBeschl.UseVisualStyleBackColor = True
        '
        'chkAuslenk
        '
        Me.chkAuslenk.AutoSize = True
        Me.chkAuslenk.Checked = True
        Me.chkAuslenk.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkAuslenk.ForeColor = System.Drawing.Color.Red
        Me.chkAuslenk.Location = New System.Drawing.Point(201, 44)
        Me.chkAuslenk.Name = "chkAuslenk"
        Me.chkAuslenk.Size = New System.Drawing.Size(82, 17)
        Me.chkAuslenk.TabIndex = 6
        Me.chkAuslenk.Text = "Auslenkung"
        Me.chkAuslenk.UseVisualStyleBackColor = True
        '
        'optLinie
        '
        Me.optLinie.AutoSize = True
        Me.optLinie.Checked = True
        Me.optLinie.Location = New System.Drawing.Point(14, 12)
        Me.optLinie.Name = "optLinie"
        Me.optLinie.Size = New System.Drawing.Size(93, 17)
        Me.optLinie.TabIndex = 7
        Me.optLinie.TabStop = True
        Me.optLinie.Text = "Linie zeichnen"
        Me.optLinie.UseVisualStyleBackColor = True
        '
        'optPunkt
        '
        Me.optPunkt.AutoSize = True
        Me.optPunkt.Location = New System.Drawing.Point(14, 35)
        Me.optPunkt.Name = "optPunkt"
        Me.optPunkt.Size = New System.Drawing.Size(105, 17)
        Me.optPunkt.TabIndex = 8
        Me.optPunkt.Text = "Punkte zeichnen"
        Me.optPunkt.UseVisualStyleBackColor = True
        '
        'lblZoomwert
        '
        Me.lblZoomwert.AutoSize = True
        Me.lblZoomwert.Location = New System.Drawing.Point(585, 17)
        Me.lblZoomwert.Name = "lblZoomwert"
        Me.lblZoomwert.Size = New System.Drawing.Size(76, 13)
        Me.lblZoomwert.TabIndex = 9
        Me.lblZoomwert.Text = "Zoomwert in %"
        '
        'frmDiagramm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(686, 464)
        Me.Controls.Add(Me.lblZoomwert)
        Me.Controls.Add(Me.optPunkt)
        Me.Controls.Add(Me.optLinie)
        Me.Controls.Add(Me.chkAuslenk)
        Me.Controls.Add(Me.chkBeschl)
        Me.Controls.Add(Me.chkGeschw)
        Me.Controls.Add(Me.cmdZoomplus)
        Me.Controls.Add(Me.cmdZoomminus)
        Me.Controls.Add(Me.cmdReset)
        Me.Controls.Add(Me.cmdAutoscale)
        Me.Name = "frmDiagramm"
        Me.Text = "Diagramm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdAutoscale As System.Windows.Forms.Button
    Friend WithEvents cmdReset As System.Windows.Forms.Button
    Friend WithEvents cmdZoomminus As System.Windows.Forms.Button
    Friend WithEvents cmdZoomplus As System.Windows.Forms.Button
    Friend WithEvents chkGeschw As System.Windows.Forms.CheckBox
    Friend WithEvents chkBeschl As System.Windows.Forms.CheckBox
    Friend WithEvents chkAuslenk As System.Windows.Forms.CheckBox
    Friend WithEvents optLinie As System.Windows.Forms.RadioButton
    Friend WithEvents optPunkt As System.Windows.Forms.RadioButton
    Friend WithEvents lblZoomwert As System.Windows.Forms.Label
End Class
