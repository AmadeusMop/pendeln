﻿Public Class frmDiagramm

    'Deklaration von Variablen:
    Dim phimax As Decimal

    'Eigenschaften des Fenster:
    Private Sub Diagramm_Load(sender As Object, e As EventArgs) Handles Me.Load
        DoubleBuffered = True                               'Es findet eine doppelte Bufferung statt um ein Flimmern zu reduzieren
        Me.Left = 805                                       'Position/Abstand des Fensters von links
        Me.Top = 350                                        'Position/Abestand des Fensters von oben
        Me.Width = 700                                      'Breite des Fensters
        Me.Height = 500                                     'Höhe des Fensters
    End Sub



    Private Sub frmDiagramm_Paint(sender As Object, e As PaintEventArgs) Handles Me.Paint

        'Deklaration von weiteren Variablen:

        Dim xAxisPosx As Integer = 10                       'Beginn des Diagramms vom linken Rand
        Dim xAxisPosy As Integer = 250                      'Beginn des Diagramms vom oberen Rand
        Dim diagLength As Decimal = Me.Width - 35           'Für die Breite des Diagramm
        Dim diagHeight As Decimal = Me.Height - 200         'Für die Höhe des Diagramms

        Dim x0 As Decimal                                   'Für die x-Position des vorherigen Wertes
        Dim x1 As Decimal                                   'Für die x-Position des aktuellen Wertes
        Dim yWink0 As Decimal                               'Für die y-Position des vorherigen Wertes (Auslenkung)
        Dim yWink1 As Decimal                               'Für die y-Position des aktuellen Wertes (Auslenkung)
        Dim yGeschw0 As Decimal                             'Für die y-Position des vorherigen Wertes (Geschwindigkeit)
        Dim yGeschw1 As Decimal                             'Für die y-Position des aktuellen Wertes (Geschwindigkeit)
        Dim yBeschl0 As Decimal                             'Für die y-Position des vorherigen Wertes (Beschleunigung)
        Dim yBeschl1 As Decimal                             'Für die y-Position des aktuellen Wertes (Beschleunigung)

        Dim rand As New Pen(Color.Black, 2)                 'Farbe und Dicke der Linie für den Rand
        Dim xAchse As New Pen(Color.Black, 1)               'Farbe und Dicke der Linie für die x-Achse

        Dim sinWinkel As New Pen(Color.Red, 2)              'Farbe und Dicke der Linie für die Auslenkung
        Dim sinGeschw As New Pen(Color.Blue, 2)             'Farbe und Dicke der Linie für die Geschwindigkeit
        Dim sinBeschl As New Pen(Color.Green, 2)            'Farbe und Dicke der Linien für die Beschleunigung


        'Hier wird gezeichnet:
        With e.Graphics
            .FillRectangle(Brushes.AliceBlue, xAxisPosx, xAxisPosy - diagHeight / 2, diagLength, diagHeight)    'zeichnet den blauen Hintergrund des Diagramms
            .DrawRectangle(rand, xAxisPosx, xAxisPosy - diagHeight / 2, diagLength, diagHeight)                 'zeichnet den schwarzen Rand des Diagramms
            .DrawLine(xAchse, xAxisPosx, xAxisPosy, xAxisPosx + diagLength, xAxisPosy)                          'zeichnet die x-Achse
        End With

        'Alte und neue x-/y-Positionen werden bestimmt
        For i = 1 To frmStart.n - 1                                         'geht alle Messpunkte/Elemente im Array durch
            x0 = xAxisPosx + (i - 1) * diagLength / 100                     'x-Wert des letzten Punktes
            x1 = xAxisPosx + (i) * diagLength / 100                         'x-Wert des jetzigen Punktes
            yWink0 = xAxisPosy - frmStart.phiw(i - 1) * frmStart.zoom       'y-Wert des letzten Punktes (Auslenkung)
            yWink1 = xAxisPosy - frmStart.phiw(i) * frmStart.zoom           'y-Wert des jetzigen Punktes (Auslenkung)
            yGeschw0 = xAxisPosy - frmStart.phis(i - 1) * frmStart.zoom     'y-Werte des letzten Punktes (Geschwindigkeit)
            yGeschw1 = xAxisPosy - frmStart.phis(i) * frmStart.zoom         'y-Werte des jetzigen Punktes (Geschwindigkeit)
            yBeschl0 = xAxisPosy - frmStart.phia(i - 1) * frmStart.zoom     'y-Werte des letzten Punktes (Beschleunigung)
            yBeschl1 = xAxisPosy - frmStart.phia(i) * frmStart.zoom         'y-Werte des jetzigen Punktes (Beschleunigung)


            'Zeichnung der Linien oder Punkte
            If optLinie.Checked = True Then                                             'Linie zeichnen ausgewählt

                If chkAuslenk.Checked = True Then                                       'wenn Auslenkung ausgewählt ist
                    e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality      'Antialiasing
                    e.Graphics.DrawLine(sinWinkel, x0, yWink0, x1, yWink1)              'zeichnet die Linie zwischen dem letzten und dem jetzigen Punkt
                End If
                If chkGeschw.Checked = True Then                                        'wenn Geschwindigkeit ausgewählt ist
                    e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality      'Antialiasing
                    e.Graphics.DrawLine(sinGeschw, x0, yGeschw0, x1, yGeschw1)          'zeichnet die Linie zwischen dem letzten und dem jetzigen Punkt
                End If
                If chkBeschl.Checked = True Then                                        'wenn Beschleunigung ausgewählt ist
                    e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality      'Antialiasing
                    e.Graphics.DrawLine(sinBeschl, x0, yBeschl0, x1, yBeschl1)          'zeichnet die Linie zwischen dem letzten und dem jetzigen Punkt
                End If
            Else                                                                        'Punkte zeichnen ausgewählt

                If chkAuslenk.Checked = True Then                                       'wenn Auslenkung ausgewählt ist
                    e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality      'Antialiasing
                    e.Graphics.FillEllipse(Brushes.Red, x0 - 2, yWink0 - 2, 4, 4)       'zeichnet Kreis des Punktes
                End If
                If chkGeschw.Checked = True Then                                        'wenn Geschwindigkeit ausgewählt ist
                    e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality      'Antialiasing
                    e.Graphics.FillEllipse(Brushes.Blue, x0 - 2, yGeschw0 - 2, 4, 4)    'zeichnet Kreis des Punktes
                End If
                If chkBeschl.Checked = True Then                                        'wenn Beschleunigung ausgewählt ist
                    e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.HighQuality      'Antialiasing
                    e.Graphics.FillEllipse(Brushes.Green, x0 - 2, yBeschl0 - 2, 4, 4)   'zeichnet Kreis des Punktes
                End If
            End If
        Next
    End Sub




    'Button für den Autoscale
    Private Sub cmdAutoscale_Click(sender As Object, e As EventArgs) Handles cmdAutoscale.Click
        phimax = 0
        For i = 0 To 100                                                                        'Sucht nach dem höchsten Wert in den Arrays
            If Math.Abs(frmStart.phia(i)) > phimax And chkBeschl.Checked = True Then            'nur wenn der jeweilige Haken gesetzt ist
                phimax = Math.Abs(frmStart.phia(i))                                             'Wenn Wert größer als jetziger Max ist, speichern
            Else
                If Math.Abs(frmStart.phis(i)) > phimax And chkGeschw.Checked = True Then        'nur wenn der jeweilige Haken gesetzt ist
                    phimax = Math.Abs(frmStart.phis(i))                                         'Wenn Wert größer als jetziger Max ist, speichern
                Else
                    If Math.Abs(frmStart.phiw(i)) > phimax And chkAuslenk.Checked = True Then   'nur wenn der jeweilige Haken gesetzt ist
                        phimax = Math.Abs(frmStart.phiw(i))                                     'Wenn Wert größer als jetziger Max ist, speichern
                    End If
                End If
            End If
        Next
        frmStart.zoom = ((Me.Height - 200) / 2.03) / phimax                                     'Berechnung des Zooms mithilfe des höchsten Wertes
        lblZoomwert.Text = "Zoom:" & frmStart.zoom & "%"                                        'Ausgabe aktueller Wert des Zooms
    End Sub


    'Button für die Vergrößerung
    Private Sub cmdZoomplus_Click1(sender As Object, e As EventArgs) Handles cmdZoomplus.Click
        frmStart.zoom = frmStart.zoom * 1.3                                                     'Zoomwert wird vergrößert
        lblZoomwert.Text = "Zoom:" & frmStart.zoom & "%"                                        'Ausgabe des Wertes
    End Sub


    'Button für die Verkleinerung
    Private Sub cmdZoomminus_Click1(sender As Object, e As EventArgs) Handles cmdZoomminus.Click
        frmStart.zoom = frmStart.zoom * 0.7                                                     'Zoomwert wird verkleinert
        lblZoomwert.Text = "Zoom:" & frmStart.zoom & "%"                                        'Ausgabe des Wertes
    End Sub


    'Button für den Rest
    Private Sub cmdReset_Click1(sender As Object, e As EventArgs) Handles cmdReset.Click
        frmStart.zoom = 100                                                                     'Zoomwert wird zurück auf 100 gesetzt
        lblZoomwert.Text = "Zoom:" & frmStart.zoom & "%"                                        'Ausgabe des Wertes
    End Sub
End Class