﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMesswerte
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblAuslenkung = New System.Windows.Forms.Label()
        Me.lblGeschwindigkeit = New System.Windows.Forms.Label()
        Me.lblBeschleunigung = New System.Windows.Forms.Label()
        Me.lblZeit = New System.Windows.Forms.Label()
        Me.lblAuslenkungswert1 = New System.Windows.Forms.Label()
        Me.lblGeschwindigkeitWert1 = New System.Windows.Forms.Label()
        Me.lblBeschleunigungWert1 = New System.Windows.Forms.Label()
        Me.lblEntspricht1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblBeschleunigungWert2 = New System.Windows.Forms.Label()
        Me.lblGeschwindigkeitWert2 = New System.Windows.Forms.Label()
        Me.lblAuslenkungswert2 = New System.Windows.Forms.Label()
        Me.lblZeitanzeige = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblAuslenkung
        '
        Me.lblAuslenkung.AutoSize = True
        Me.lblAuslenkung.Location = New System.Drawing.Point(17, 21)
        Me.lblAuslenkung.Name = "lblAuslenkung"
        Me.lblAuslenkung.Size = New System.Drawing.Size(66, 13)
        Me.lblAuslenkung.TabIndex = 0
        Me.lblAuslenkung.Text = "Auslenkung:"
        '
        'lblGeschwindigkeit
        '
        Me.lblGeschwindigkeit.AutoSize = True
        Me.lblGeschwindigkeit.Location = New System.Drawing.Point(17, 48)
        Me.lblGeschwindigkeit.Name = "lblGeschwindigkeit"
        Me.lblGeschwindigkeit.Size = New System.Drawing.Size(88, 13)
        Me.lblGeschwindigkeit.TabIndex = 1
        Me.lblGeschwindigkeit.Text = "Geschwindigkeit:"
        '
        'lblBeschleunigung
        '
        Me.lblBeschleunigung.AutoSize = True
        Me.lblBeschleunigung.Location = New System.Drawing.Point(17, 74)
        Me.lblBeschleunigung.Name = "lblBeschleunigung"
        Me.lblBeschleunigung.Size = New System.Drawing.Size(86, 13)
        Me.lblBeschleunigung.TabIndex = 2
        Me.lblBeschleunigung.Text = "Beschleunigung:"
        '
        'lblZeit
        '
        Me.lblZeit.AutoSize = True
        Me.lblZeit.Location = New System.Drawing.Point(17, 100)
        Me.lblZeit.Name = "lblZeit"
        Me.lblZeit.Size = New System.Drawing.Size(28, 13)
        Me.lblZeit.TabIndex = 3
        Me.lblZeit.Text = "Zeit:"
        '
        'lblAuslenkungswert1
        '
        Me.lblAuslenkungswert1.AutoSize = True
        Me.lblAuslenkungswert1.Location = New System.Drawing.Point(140, 21)
        Me.lblAuslenkungswert1.Name = "lblAuslenkungswert1"
        Me.lblAuslenkungswert1.Size = New System.Drawing.Size(44, 13)
        Me.lblAuslenkungswert1.TabIndex = 4
        Me.lblAuslenkungswert1.Text = "WAusl1"
        '
        'lblGeschwindigkeitWert1
        '
        Me.lblGeschwindigkeitWert1.AutoSize = True
        Me.lblGeschwindigkeitWert1.Location = New System.Drawing.Point(140, 48)
        Me.lblGeschwindigkeitWert1.Name = "lblGeschwindigkeitWert1"
        Me.lblGeschwindigkeitWert1.Size = New System.Drawing.Size(63, 13)
        Me.lblGeschwindigkeitWert1.TabIndex = 5
        Me.lblGeschwindigkeitWert1.Text = "WGeschw1"
        '
        'lblBeschleunigungWert1
        '
        Me.lblBeschleunigungWert1.AutoSize = True
        Me.lblBeschleunigungWert1.Location = New System.Drawing.Point(140, 74)
        Me.lblBeschleunigungWert1.Name = "lblBeschleunigungWert1"
        Me.lblBeschleunigungWert1.Size = New System.Drawing.Size(56, 13)
        Me.lblBeschleunigungWert1.TabIndex = 6
        Me.lblBeschleunigungWert1.Text = "WBeschl1"
        '
        'lblEntspricht1
        '
        Me.lblEntspricht1.AutoSize = True
        Me.lblEntspricht1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEntspricht1.Location = New System.Drawing.Point(203, 16)
        Me.lblEntspricht1.Name = "lblEntspricht1"
        Me.lblEntspricht1.Size = New System.Drawing.Size(17, 20)
        Me.lblEntspricht1.TabIndex = 7
        Me.lblEntspricht1.Text = "≙"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(203, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(17, 20)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "≙"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(203, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(17, 20)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "≙"
        '
        'lblBeschleunigungWert2
        '
        Me.lblBeschleunigungWert2.AutoSize = True
        Me.lblBeschleunigungWert2.Location = New System.Drawing.Point(226, 76)
        Me.lblBeschleunigungWert2.Name = "lblBeschleunigungWert2"
        Me.lblBeschleunigungWert2.Size = New System.Drawing.Size(56, 13)
        Me.lblBeschleunigungWert2.TabIndex = 12
        Me.lblBeschleunigungWert2.Text = "WBeschl2"
        '
        'lblGeschwindigkeitWert2
        '
        Me.lblGeschwindigkeitWert2.AutoSize = True
        Me.lblGeschwindigkeitWert2.Location = New System.Drawing.Point(226, 50)
        Me.lblGeschwindigkeitWert2.Name = "lblGeschwindigkeitWert2"
        Me.lblGeschwindigkeitWert2.Size = New System.Drawing.Size(63, 13)
        Me.lblGeschwindigkeitWert2.TabIndex = 11
        Me.lblGeschwindigkeitWert2.Text = "WGeschw2"
        '
        'lblAuslenkungswert2
        '
        Me.lblAuslenkungswert2.AutoSize = True
        Me.lblAuslenkungswert2.Location = New System.Drawing.Point(226, 23)
        Me.lblAuslenkungswert2.Name = "lblAuslenkungswert2"
        Me.lblAuslenkungswert2.Size = New System.Drawing.Size(44, 13)
        Me.lblAuslenkungswert2.TabIndex = 10
        Me.lblAuslenkungswert2.Text = "WAusl2"
        '
        'lblZeitanzeige
        '
        Me.lblZeitanzeige.AutoSize = True
        Me.lblZeitanzeige.Location = New System.Drawing.Point(143, 100)
        Me.lblZeitanzeige.Name = "lblZeitanzeige"
        Me.lblZeitanzeige.Size = New System.Drawing.Size(39, 13)
        Me.lblZeitanzeige.TabIndex = 13
        Me.lblZeitanzeige.Text = "Label3"
        '
        'frmMesswerte
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(381, 184)
        Me.Controls.Add(Me.lblZeitanzeige)
        Me.Controls.Add(Me.lblBeschleunigungWert2)
        Me.Controls.Add(Me.lblGeschwindigkeitWert2)
        Me.Controls.Add(Me.lblAuslenkungswert2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblEntspricht1)
        Me.Controls.Add(Me.lblBeschleunigungWert1)
        Me.Controls.Add(Me.lblGeschwindigkeitWert1)
        Me.Controls.Add(Me.lblAuslenkungswert1)
        Me.Controls.Add(Me.lblZeit)
        Me.Controls.Add(Me.lblBeschleunigung)
        Me.Controls.Add(Me.lblGeschwindigkeit)
        Me.Controls.Add(Me.lblAuslenkung)
        Me.Name = "frmMesswerte"
        Me.Text = "Messwerte"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblAuslenkung As System.Windows.Forms.Label
    Friend WithEvents lblGeschwindigkeit As System.Windows.Forms.Label
    Friend WithEvents lblBeschleunigung As System.Windows.Forms.Label
    Friend WithEvents lblZeit As System.Windows.Forms.Label
    Friend WithEvents lblAuslenkungswert1 As System.Windows.Forms.Label
    Friend WithEvents lblGeschwindigkeitWert1 As System.Windows.Forms.Label
    Friend WithEvents lblBeschleunigungWert1 As System.Windows.Forms.Label
    Friend WithEvents lblEntspricht1 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblBeschleunigungWert2 As System.Windows.Forms.Label
    Friend WithEvents lblGeschwindigkeitWert2 As System.Windows.Forms.Label
    Friend WithEvents lblAuslenkungswert2 As System.Windows.Forms.Label
    Friend WithEvents lblZeitanzeige As System.Windows.Forms.Label
End Class
