﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPendel2D
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkoriginal = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'chkoriginal
        '
        Me.chkoriginal.AutoSize = True
        Me.chkoriginal.Location = New System.Drawing.Point(12, 12)
        Me.chkoriginal.Name = "chkoriginal"
        Me.chkoriginal.Size = New System.Drawing.Size(87, 17)
        Me.chkoriginal.TabIndex = 0
        Me.chkoriginal.Text = "Originallänge"
        Me.chkoriginal.UseVisualStyleBackColor = True
        '
        'frmPendel2D
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(404, 343)
        Me.Controls.Add(Me.chkoriginal)
        Me.Name = "frmPendel2D"
        Me.Text = "Pendel2d"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chkoriginal As System.Windows.Forms.CheckBox
End Class
